@echo off
chcp 1251 >nul

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

set "ext=.snx"
set "fileType=SnxFileType"
set "iconPath=%~dp0icon.ico"
set "batchPath=%~dp0main.bat"

reg add "HKEY_CLASSES_ROOT\%ext%" /ve /t REG_SZ /d "%fileType%" /f
reg add "HKEY_CLASSES_ROOT\%fileType%\DefaultIcon" /ve /t REG_SZ /d "%iconPath%,0" /f
reg add "HKEY_CLASSES_ROOT\%fileType%\shell\open\command" /ve /t REG_SZ /d "cmd.exe /k \"\"%batchPath%\" \"%%1\"\"" /f

taskkill /f /im explorer.exe
start explorer.exe

echo Registration complete.
pause