@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul

set "filePath=%~1"
set "game_path=%userprofile%\Games\senix"

if "%filePath%"=="" (
    echo [ERROR] Please specify the path to the .snx file.
    pause
    exit /b
)
if not exist "%filePath%" (
    echo [ERROR] File "%filePath%" not found.
    pause
    exit /b
)

echo -----------------------------------------
echo .snx document: "%filePath%"
echo -----------------------------------------
echo.
echo Progressing:
echo.

call :exec_file "%filePath%"

echo.
echo -----------------------------------------
pause
exit /b

:: =========================================
:: ЯДРО ИНТЕРПРЕТАТОРА (ПОСТРОЧНЫЙ ПАРСЕР)
:: =========================================
:exec_file
setlocal
set "cur_file=%~1"
set "cur_dir=%~dp1"
set /a total_lines=0
set /a silent_mode=0
set /a log_num=0

:: Загружаем все строки файла в память в виде массива line_1, line_2...
for /f "usebackq delims=" %%a in ("%cur_file%") do (
    set /a total_lines+=1
    set "line_!total_lines!=%%a"
)

set /a pc=1
:loop_start
if !pc! gtr !total_lines! (
    endlocal
    goto :eof
)

:: Берем текущую строку и убираем лишние пробелы в начале
set "raw=!line_%pc%!"
for /f "tokens=* delims= " %%t in ("!raw!") do set "raw=%%t"

:: Пропускаем пустые строки и комментарии #
if "!raw!"=="" goto :next_line
if "!raw:~0,1!"=="#" goto :next_line

:: --- ОБЪЯВЛЕНИЕ ФУНКЦИИ (fun name) ---
if /i "!raw:~0,4!"=="fun " (
    set "fname=!raw:~4!"
    set /a "func_start_!fname!=!pc! + 1"
    call :skip_to_end !pc!
    set /a pc=!skip_result!
    goto :next_line
)

:: --- ВЫЗОВ ФУНКЦИИ (run name) ---
if /i "!raw:~0,4!"=="run " (
    set "fname=!raw:~4!"
    if defined func_start_!fname! (
        set /a "ret_pc=!pc!"
        set /a "pc=func_start_!fname!"
        goto :loop_start
    ) else (
        echo [ERROR] Function "!fname!" not found.
        goto :next_line
    )
)

:: --- ЦИКЛ (repeat N) ---
if /i "!raw:~0,7!"=="repeat " (
    set "rcnt_raw=!raw:~7!"
    call :resolve_vars "!rcnt_raw!" rcnt
    set /a "loop_start_pc=!pc! + 1"
    set /a "loop_left=!rcnt!"
    if !loop_left! leq 0 (
        call :skip_to_end !pc!
        set /a pc=!skip_result!
    )
    goto :next_line
)

:: --- УСЛОВИЕ (if A op B) ---
if /i "!raw:~0,3!"=="if " (
    set "cond_raw=!raw:~3!"
    call :resolve_vars "!cond_raw!" cond_eval
    call :check_cond "!cond_eval!" is_true
    if "!is_true!"=="0" (
        call :skip_to_else_or_end !pc!
        set /a pc=!skip_result!
    )
    goto :next_line
)

:: --- ВЕТКА ELSE ---
if /i "!raw!"=="else" (
    call :skip_to_end !pc!
    set /a pc=!skip_result!
    goto :next_line
)

:: --- КОНЕЦ БЛОКА (end) ---
if /i "!raw!"=="end" (
    if defined loop_left (
        set /a loop_left-=1
        if !loop_left! gtr 0 (
            set /a pc=!loop_start_pc!
            goto :loop_start
        ) else (
            set "loop_left="
            goto :next_line
        )
    )
    if defined ret_pc (
        set /a pc=!ret_pc!
        set "ret_pc="
        goto :next_line
    )
    goto :next_line
)

:: Подставляем переменные {var} в строку
call :resolve_vars "!raw!" line

if !silent_mode! equ 0 (
    set /a log_num+=1
    echo !log_num!. !line!
)

for /f "tokens=1,* delims= " %%b in ("!line!") do (
    call :dispatch "%%b" "%%c"
)

:next_line
set /a pc+=1
goto :loop_start

:: =========================================
:: ВСПОМОГАТЕЛЬНЫЕ ПРОЦЕДУРЫ ПАРСЕРА
:: =========================================
:resolve_vars
set "tmp_str=%~1"
for /f "tokens=1,* delims==" %%v in ('set var_ 2^>nul') do (
    set "vn=%%v"
    set "vn=!vn:var_=!"
    set "vv=%%w"
    call set "tmp_str=%%tmp_str:{!vn!}=!vv!%%"
)
set "%~2=!tmp_str!"
goto :eof

:check_cond
set "c_str=%~1"
set "%~2=0"
for /f "tokens=1,2,3 delims= " %%x in ("!c_str!") do (
    set "op=%%y"
    if "!op!"=="==" if "%%x"=="%%z" set "%~2=1"
    if "!op!"=="!=" if not "%%x"=="%%z" set "%~2=1"
    if "!op!"==">"  if %%x gtr %%z set "%~2=1"
    if "!op!"=="<"  if %%x lss %%z set "%~2=1"
    if "!op!"==">=" if %%x geq %%z set "%~2=1"
    if "!op!"=="<=" if %%x leq %%z set "%~2=1"
)
goto :eof

:skip_to_end
set /a s_idx=%~1 + 1
set /a depth=1
:ste_loop
if !s_idx! gtr !total_lines! ( set /a skip_result=!total_lines! & goto :eof )
set "s_line=!line_%s_idx%!"
for /f "tokens=* delims= " %%t in ("!s_line!") do set "s_line=%%t"
if /i "!s_line:~0,4!"=="fun " set /a depth+=1
if /i "!s_line:~0,7!"=="repeat " set /a depth+=1
if /i "!s_line:~0,3!"=="if " set /a depth+=1
if /i "!s_line!"=="end" set /a depth-=1
if !depth! equ 0 ( set /a skip_result=!s_idx! & goto :eof )
set /a s_idx+=1
goto :ste_loop

:skip_to_else_or_end
set /a s_idx=%~1 + 1
set /a depth=1
:stee_loop
if !s_idx! gtr !total_lines! ( set /a skip_result=!total_lines! & goto :eof )
set "s_line=!line_%s_idx%!"
for /f "tokens=* delims= " %%t in ("!s_line!") do set "s_line=%%t"
if /i "!s_line:~0,4!"=="fun " set /a depth+=1
if /i "!s_line:~0,7!"=="repeat " set /a depth+=1
if /i "!s_line:~0,3!"=="if " set /a depth+=1
if !depth! equ 1 if /i "!s_line!"=="else" ( set /a skip_result=!s_idx! & goto :eof )
if /i "!s_line!"=="end" set /a depth-=1
if !depth! equ 0 ( set /a skip_result=!s_idx! & goto :eof )
set /a s_idx+=1
goto :stee_loop

:dispatch
set "cmd=%~1"
set "args=%~2"
findstr /i /b /c:":cmd_%cmd%" "%~f0" >nul
if errorlevel 1 (
    echo [WARNING] Unknown command: %cmd%
    goto :eof
)
call :cmd_%cmd% "%args%"
goto :eof

:: =========================================
:: ВСЕ КОМАНДЫ ЯЗЫКА .SNX
:: =========================================
:cmd_let
for /f "tokens=1,* delims==" %%x in ("%~1") do (
    for /f "tokens=1" %%k in ("%%x") do set "vk=%%k"
    set "vv=%%y"
    if "!vv:~0,1!"==" " set "vv=!vv:~1!"
    set "var_!vk!=!vv!"
)
goto :eof

:cmd_calc
for /f "tokens=1,* delims==" %%x in ("%~1") do (
    for /f "tokens=1" %%k in ("%%x") do set "vk=%%k"
    set /a "res=%%y"
    set "var_!vk!=!res!"
)
goto :eof

:cmd_rnd
for /f "tokens=1,2,3 delims= " %%x in ("%~1") do (
    set /a "diff=%%z - %%y + 1"
    set /a "var_%%x=!random! %% !diff! + %%y"
)
goto :eof

:import
set "mod=%~1"
if exist "%mod%" (
    call :exec_file "%mod%"
) else if exist "%cur_dir%%mod%" (
    call :exec_file "%cur_dir%%mod%"
) else (
    echo [IMPORT ERROR] Module "%mod%" not found.
)
goto :eof

:cmd_say
set "say_txt=%~1"
echo.!say_txt!
goto :eof

:cmd_userput
for /f "tokens=1,* delims= " %%x in ("%~1") do (
    set /p "var_%%x=%%y "
)
goto :eof

:cmd_wait
set "sec=%~1"
if "%sec%"=="" set "sec=1"
timeout /t %sec% /nobreak >nul
goto :eof

:cmd_clear
cls
goto :eof

:cmd_title
title %~1
goto :eof

:cmd_off_msg
set /a silent_mode=1
goto :eof

:cmd_on_msg
set /a silent_mode=0
goto :eof

:cmd_get
for /f "tokens=1,* delims= " %%x in ("%~1") do (
    set "req_var=%%x"
    set "req_url=%%y"
)

set "var_!req_var!=ERROR"

for /f "delims=" %%r in ('powershell -NoProfile -Command "try { $r = Invoke-WebRequest -Uri '!req_url!' -UseBasicParsing -TimeoutSec 10; $r.Content -replace '[\r\n]+', ' ' } catch { 'ERROR' }"') do (
    set "var_!req_var!=%%r"
)
goto :eof

:cmd_aktc
pause
goto :eof

:cmd_in
if exist "%~1" ( cd /d "%~1" ) else ( echo [ERROR] Directory "%~1" not found. )
goto :eof

:cmd_delete
echo !cd! | findstr /i /c:"%game_path%" >nul
if errorlevel 1 (
    echo [SECURITY BLOCK] Deletion forbidden outside %game_path%
    goto :eof
)
echo Process wants to delete files in: "!cd!"
pause
del /s /q /f * >nul 2>&1
for /d %%i in (*) do rd /s /q "%%i" >nul 2>&1
echo Folder cleaned.
goto :eof

:cmd_matrix
color 02
for /l %%i in (1,1,100) do echo !random!!random!!random!!random!
goto :eof

:cmd_ftree
tree /f /a
goto :eof

:cmd_download
for /f "tokens=1,* delims= " %%x in ("%~1") do (
    set "dl_url=%%x"
    set "dl_file=%%y"
)

set "dl_target=!cur_dir_%lvl%!!dl_file!"
set "var_dl_status=ERROR"

powershell -NoProfile -Command "try { Invoke-WebRequest -Uri '!dl_url!' -OutFile '!dl_target!' -UseBasicParsing -TimeoutSec 15; exit 0 } catch { exit 1 }"

if !errorlevel! equ 0 (
    set "var_dl_status=OK"
)
goto :eof


:cmd_open_url
start "" "%~1"
goto :eof

:cmd_yt
start "" "https://youtube.com"
goto :eof

:cmd_beep
powershell -Command "[console]::beep(800, 300)"
goto :eof

:cmd_msg
set "txt=%~1"
set "txt=%txt:"=%"
powershell -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('%txt%', 'SENIPIX') | Out-Null"
goto :eof

:cmd_post
for /f "tokens=1,* delims= " %%x in ("%~1") do (
    set "post_url=%%x"
    set "post_msg=%%y"
)

set "post_msg=!post_msg:"=\"!"
set "post_msg=!post_msg:'=''!"

set "var_post_status=ERROR"

powershell -NoProfile -Command "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $body = '{\"content\": \"!post_msg!\"}'; Invoke-RestMethod -Uri '!post_url!' -Method Post -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -ContentType 'application/json; charset=utf-8' -TimeoutSec 10 | Out-Null; exit 0 } catch { exit 1 }"

if !errorlevel! equ 0 (
    set "var_post_status=OK"
)
goto :eof


:cmd_speak
set "spk=%~1"
set "spk=%spk:'=''%"
powershell -Command "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak('%spk%')"
goto :eof


:cmd_ip
echo [SENIPIX] Fetching IP...
powershell -Command "(Invoke-WebRequest -uri 'https://ifconfig.me').Content"
goto :eof

:cmd_sysinfo
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"Total Physical Memory"
goto :eof
